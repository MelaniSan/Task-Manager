﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager.Models;
using Task = TaskManager.Models.Task;

namespace TaskManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly TaskDbContext _dbContext;

        public TaskController(TaskDbContext dbContext) 
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Task>>> GetTasks()
        {
            if(_dbContext.Tasks == null)
            {
                return NotFound();
            }
            return await _dbContext.Tasks.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Task>> GetTask(int id)
        {
            if (_dbContext.Tasks == null)
            {
                return NotFound();
            }
            var task = await _dbContext.Tasks.FindAsync(id);
            if (task == null)
            {
                return NotFound();
            }
            return task;
        }

        [HttpPost]
        public async Task<ActionResult<Task>> PostTask(Task task)
        {
            _dbContext.Tasks.Add(task);
            await _dbContext.SaveChangesAsync();
           
            return CreatedAtAction(nameof(GetTask), new { id = task.Id }, task);
        }


        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateTask(int id, Task task)
        {
            if(id != task.Id)
            {
                return BadRequest();
            }
            _dbContext.Entry(task).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch(DbUpdateConcurrencyException)
            {
                if (!TaskAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok();

        }

        private bool TaskAvailable(int id)
        {
            return (_dbContext.Tasks? .Any(x => x.Id == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteTask(int id)
        {
            if(_dbContext.Tasks == null)
            {
                return NotFound();
            }

            var task = await _dbContext.Tasks.FindAsync(id);
            if(task == null)
            {
                return NotFound();
            }

            _dbContext.Tasks.Remove(task);

            await _dbContext.SaveChangesAsync();
            return Ok();
        }

    }
}
